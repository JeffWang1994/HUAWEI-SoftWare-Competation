# Linear-Regression
matlab implementation of linear regression algorithm with one variable.

the algorithm predicts the profits that could be gained from a city depending on it's population.
